#Nikhil Jiten Naik
#NKXNIK003
#17/04/2014
#Assignment 5-Question 3 (My Math)

