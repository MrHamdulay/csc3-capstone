#graph in program
#kiyarah pillay
#15 april 2014

import math 
#ask user to enter their function
user_function=input("Enter a function f(x):\n") 
for functionrange in range(10,-11,-1): 
        for functiondomain in range(-10,11,1):
#x values are the domain of the graph
                x=functiondomain