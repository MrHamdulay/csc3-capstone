import glob
import os
print(' '.join(glob.glob("*.txt")))
