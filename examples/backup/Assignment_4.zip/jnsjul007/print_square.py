def print_square():
    for i in range(1,6):
        if i==1 or i==5:
            print("*"*5)
        else:
            print("*   *")
print_square()