
def ndom_to_decimal(a):
    return float(a)
    
def decimal_to_ndom(a):
    return int(a)

def ndom_add(a,b):
    return a+b
def ndom_multiply(a,b):
    return a*b
    