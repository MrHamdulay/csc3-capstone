"""question3
Zikho Godana
08 May 2014"""
