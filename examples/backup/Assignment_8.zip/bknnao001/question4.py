N=eval(input("Enter the starting point N:\n"))
M=eval(input("Enter the ending point M:\n"))
print("The palindromic primes are:\n")
def Numprime():
    global j
    
            

    if j%f==0 and f!=j and j!=1:
        return 
    else:
        if j != 1:
            print(j)
Numprime()

        
