#program to see if a number is a palindrome
#kiyarah pillay
#10 may 2014

