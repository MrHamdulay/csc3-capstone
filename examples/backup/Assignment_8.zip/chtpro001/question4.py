print(" "*(len(msg)+2+thcknss-i+1),"+","-"*(i-4),"+",sep="")
    