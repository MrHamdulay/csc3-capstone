"""program to determine whether a number is both a palindrome and a prime
Lorena Dal Maso
10 May 2014"""

number = input("Enter a number:\n")