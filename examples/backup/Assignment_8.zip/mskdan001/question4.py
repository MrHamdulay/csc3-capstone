"""danson masuka
recursive functions to find all palindromic primes between two integers supplied as input 
5 may 2014"""

import sys
sys.setrecursionlimit (30000)

