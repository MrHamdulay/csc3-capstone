print("Welcome to the 30 Second Rule Expert")
print("------------------------------------")
print("Answer the following questions by selecting from among the options.")
a= input("Did anyone see you? (yes/no)\n")
if a =="yes":
    b = input("Was it a boss/lover/parent? (yes/no)\n")
    if b =="yes":
        d = input("Was it expensive? (yes/no)\n")
        if d =="yes":
            f =input("Can you cut off the part that touched the floor? (yes/no)\n")
            if f == "yes":
                print("Decision: Eat it.")
            else:
                print("Decision: Your call.")
        else:
            g =input("Is it chocolate? (yes/no)\n")
            if g=="yes":
                print("Decision: Eat it.")
            else:
                print("Decision: Don't eat it.")
    else:
        print("Decision: Eat it.")
else:
    c = input("Was it sticky? (yes/no)\n")
    if c == "yes":
        e =input("Is it a raw steak? (yes/no)\n")
        if e=="yes":
            k=input("Are you a puma? (yes/no)\n")
            if k=="yes":
                print("Decision: Eat it.")
            else:
                print("Decision: Don't eat it.")
        else:
            l = input("Did the cat lick it? (yes/no)\n")
            if l=="yes":
                m= input("Is your cat healthy? (yes/no)\n")
                if m=="yes":
                    print("Decision: Eat it.")
                else:
                    print("Decision: Your call.")
            else:
                print("Decision: Dont eat it.")
    else:
        f = input("Is it an Emausaurus? (yes/no)\n")
        if f == "yes":
            h = input("Are you a Megalosaurus? (yes/no)\n")
            if h == "yes":
                print("Decision: Eat it.")
            else:
                print("Decision: Don't eat it.")
        else:
            i = input("Did the cat lick it? (yes/no)\n")
            if i=="yes":
                j=input("Is your cat healthy? (yes/no)\n")
                if j=="yes":
                    print("Decision: Eat it.")
                else:
                    print("Decision: Your call.")
            else:
                print("Decision: Eat it.")
    
    
                        
 