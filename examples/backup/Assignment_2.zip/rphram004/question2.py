print("Welcome to the 30 Second Rule Expert")
print("-"*36)
print("Answer the following questions by selecting from among the options.")
x = input("Did anyone see you? (yes/no)\n")
if x=='yes':
        y = input("Was it a boss/lover/parent? (yes/no)\n")
        if y=='no':
            print("Decision: Eat it.")
        else:
            a = input("Was it expensive? (yes/no)\n")
            if a=='no':
                b = input("Is it chocolate? (yes/no)\n")
                if b=='no':
                    print("Decision: Don't eat it.")
                else:
                    print("Decision: Eat it.")
            else:
                c = input("Can you cut off the part that touched the floor? (yes/no)\n")
                if c=='yes':
                    print("Decision: Eat it.")
                else:
                    print("Decision: Your call.")
else:
        d = input("Was it sticky? (yes/no)\n")
        if d=='no':
            e = input("Is it an Emausaurus? (yes/no)\n")
            if e=='yes':
                f = input("Are you a Megalosaurus? (yes/no)\n")
                if f=='yes':
                    print("Decision: Eat it.")
                else:
                    print("Decision: Don't eat it.")
            else:
                g = input("Did the cat lick it? (yes/no)\n")
                if g=='no':
                    print("Decision: Eat it.")
                else: 
                        h = input("Is your cat healthy? (yes/no)\n")
                if h=='no':
                        print("Decision: Your call.")
                else:
                        print("Decision: Eat it.")
        else:
            j = input("Is it a raw steak? (yes/no)\n")
            if j=='yes':
                k = input("Are you a puma? (yes/no)\n")
                if k=='no':
                    print("Decision: Don't eat it.")
                else:
                    print("Decision: Eat it.")
            else:
                l = input("Did the cat lick it? (yes/no)\n")
                if l=='no':
                    print("Decision: Eat it")
                else:
                    m = input("Is your cat healthy? (yes/no)\n")
                    if m=='no':
                        print("Decision: Your call.")
                    else:
                        print("Decision: Eat it.")
                    
                    
                
                
                
            
        



