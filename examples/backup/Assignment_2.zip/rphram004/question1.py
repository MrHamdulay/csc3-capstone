x = eval(input("Enter a year:\n"))

if x%4==0 and x!=2100:
   print(x, "is a leap year.")
else:
   print(x, "is not a leap year.")



    
 