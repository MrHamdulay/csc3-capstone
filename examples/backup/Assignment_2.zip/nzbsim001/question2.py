
print('Welcome to the 30 Second Rule Expert')
print('------------------------------------')
print('Answer the following questions by selecting from among the options.')

if input('Did anyone see you? (yes/no)\n') != 'no':
    if (input('Was it a boss/lover/parent? (yes/no)\n') != 'no'):
        if (input('Was it expensive? (yes/no)\n') != 'no'):
            if (input('Can you cut off the part that touched the floor? (yes/no)\n') != 'no'):
                print('Decision: Eat it.')
            else:
                print('Decision: Your call.')
        else:
            if (input('Is it chocolate? (yes/no)\n') != 'no'):
                print('Decision: Eat it.')
            else:
                print('Decision: Don\'t eat it.')
    else:
        print('Decision: Eat it.')
else:
    if (input('Was it sticky? (yes/no)\n') != 'no'):
        if (input('Is it a raw steak? (yes/no)\n') != 'no'):
            if (input('Are you a puma? (yes/no)\n') != 'no'):
                print('Decision: Eat it.')
            else:
                print('Decision: Don\'t eat it.')
        else:
            if (input('Did the cat lick it? (yes/no)\n') != 'no'):
                if (input('Is your cat healthy? (yes/no)\n') != 'no'):
                    print('Decision: Eat it.')
                else:
                    print('Decision: Your call.')
            else:
                print('Decision: Eat it.')
    else:
        if (input('Is it an Emausaurus? (yes/no)\n') != 'no'):
            if (input('Are you a Megalosaurus? (yes/no)\n') != 'no'):
                print('Decision: Eat it.')
            else:
                print('Decision: Don\'t eat it.')
        else:
            if (input('Did the cat lick it? (yes/no)\n') != 'no'):
                if (input('Is your cat healthy? (yes/no)\n') != 'no'):
                    print('Decision: Eat it.')
                else:
                    print('Decision: Your call.')
            else:
                print('Decision: Eat it.')
