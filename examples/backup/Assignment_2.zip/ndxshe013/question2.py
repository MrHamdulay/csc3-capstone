#ASSIGNMENT 2 QUESTION 2
#STUDENT NO.: NDXSHE013

def main():
    print("Welcome to the 30 Second Rule Expert")
    print("------------------------------------")
    print("Answer the following questions by selecting from among the options.")
    z=input("Did anyone see you? (yes/no)\n")
    if z=="yes":
        y=input("Was it a boss/lover/parent? (yes/no)\n")
        if y=="yes":
            x=input("Was it expensive? (yes/no)\n")
            if x=="yes":
                w=input("Can you cut off the part that touched the floor? (yes/no)\n")
                if w=="yes":
                    print("Decision: Eat it.")
                else:
                    print("Decision: Your call.")
            else:
                v=input("Is it chocolate? (yes/no)\n")
                if v=="yes":
                    print("Decision: Eat it.")
                else:
                    print("Decision: Don't eat it.")
        else:
            print("Decision: Eat it.")
    else:
        u=input("Was it sticky? (yes/no)\n")
        if u=="yes":
            t=input("Is it a raw steak? (yes/no)\n")
            if t=="yes":
                s=input("Are you a puma? (yes/no)\n")
                if s=="yes":
                    print("Decision: Eat it.")
                else:
                    print("Decision: Don't eat it.")
            else:
                r=input("Did the cat lick it? (yes/no)\n")
                if r=="yes":
                    q=input("Is your cat healthy? (yes/no)\n")
                    if q=="yes":
                        print("Decision: Eat it.")
                    else:
                        print("Decision: Your call.")
                else:
                    print("Decision: Eat it.")
        else:
            p=input("Is it an Emausaurus? (yes/no)\n")
            if p=="yes":
                o=input("Are you a Megalosaurus? (yes/no)\n")
                if o=="yes":
                    print("Decision: Eat it.")
                else:
                    print("Decision: Don't eat it.")
            else:
                p=input("Did the cat lick it? (yes/no)\n")
                if p=="yes":
                    o=input("Is your cat healthy? (yes/no)\n")
                    if o=="yes":
                            print("Decision: Eat it.")
                    else:
                        print("Decision: Your call.")
                else:
                    print("Decision: Eat it.")
main()
    
                
            

