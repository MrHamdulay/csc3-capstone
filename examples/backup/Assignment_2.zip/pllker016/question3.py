#radius
import math
print("Approximation of pi:",(round(math.pi,3)))
rad=eval(input("Enter the radius:\n"))
area=(math.pi*(rad*rad))
print("Area:",(round(area,3)))