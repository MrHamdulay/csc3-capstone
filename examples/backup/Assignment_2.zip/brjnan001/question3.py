import math
print("Approximation of pi:",round(math.pi,3))
x=eval(input("Enter the radius: \n"))
Area=round(math.pi*(x**2),3)
print('Area:',Area)