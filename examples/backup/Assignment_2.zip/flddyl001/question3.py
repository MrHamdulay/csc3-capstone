import math
v_pi=math.pi
print("Approximation of pi:",round(v_pi,3))
v_rad=eval(input("Enter the radius:\n"))
v_sol=round(v_pi*v_rad*v_rad,3)
print("Area:",v_sol)