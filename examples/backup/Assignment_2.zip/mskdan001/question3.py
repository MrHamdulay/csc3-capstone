import math
print("Approximation of pi:",round(math.pi,3))
a=round(math.pi,3)
x=eval(input("Enter the radius:\n"))
z=math.pi*(x**2)
print("Area:",round(z,3))