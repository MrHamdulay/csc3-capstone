print("Welcome to the 30 Second Rule Expert")
print("-"*36)
print("Answer the following questions by selecting from among the options.")
w=input("Did anyone see you? (yes/no)\n")
if(w=="yes"):
    boss_lover_parent=input("Was it a boss/lover/parent? (yes/no)\n")
    if(boss_lover_parent=="yes"):
        lavish=input("Was it expensive? (yes/no)\n")
        if(lavish=="yes"):
            touch_floor=input("Can you cut off the part that touched the floor? (yes/no)\n")
            if(touch_floor=="yes"):
                print("Decision: Eat it.")
            else:
                print("Decision: Your call.")
        else:
            sweet=input("Is it chocolate? (yes/no)\n")
            if(sweet=="yes"):
                print("Decision: Eat it.")
            else:
                ("Decision: Don't eat it.")
    else:
        print("Decision: Don't eat it.")
else:
    goowy=input("Was it sticky? (yes/no)\n")
    if(goowy=="yes"):
        med_steak=input("Is it a raw steak? (yes/no)\n")
        if(med_steak=="yes"):
            pma=input("Are you a puma? (yes/no)\n")
            if(pma=="yes"):
                print("Decision: Eat it.")
            else:
                print("Decision: Don't eat it.")
        else:
            Cat_licK=input("Did the cat lick it? (yes/no)\n")
            if(Cat_licK=="yes"):
                healthy_caT=input("Is your cat healthy? (yes/no)\n")
                if(healthy_caT=="yes"):
                    print("Decision: Eat it.")
                else:
                    print("Decision: Your call.")
            else:
                print("Decision: Eat it.")
    else:
        emausaurus=input("Is it an Emausaurus? (yes/no)\n")
        if(emausaurus=="yes"):
            megalosaurus=input("Are you a Megalosaurus? (yes/no)\n")
            if(megalosaurus=="yes"):
                print("Decision: Eat it.")
            else:
                print("Decision: Don't eat it.")
        else:
            cat_licK=input("Did the cat lick it? (yes/no)\n")
            if(cat_licK=="yes"):
                healthy_caT=input("Is your cat healthy? (yes/no)\n")
                if(healthy_caT=="yes"):
                    print("Decision: Eat it.")
                else:
                    print("Decision: Your call.")
            else:
                print("Decision: Eat it.")
                       
                        
                 
                
                
        
    
     
    
    