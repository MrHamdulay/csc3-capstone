pi=3.1416
print("Approximation of pi:",round(pi,3))
x=eval(input("Enter the radius:\n"))
print("Area:",round(pi*(x**2),3))