#Sumayah Goolam Rassool
#GLMSUM001

import math

x=math.sqrt(2)
y=2
while(2/x)>1:
    y=y*2/x
    x=math.sqrt(2+x)
    pi=round(y,3)
    
print("Approximation of pi:",pi)

radius=eval(input("Enter the radius:\n"))
area=y*radius**2
area=round(area,3)
print("Area:",area)


            
    





