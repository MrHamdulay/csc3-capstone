#OFENTSE TSHEPE
#TSHRIA002
import math
x=math.pi
y=round(x,3)
print("Approximation of pi:",y)
c=eval(input("Enter the radius:\n"))
g=((c)**2)*x
print("Area:",round(g,3))