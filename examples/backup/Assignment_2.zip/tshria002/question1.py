#TSHRIA002
#OFENTSE TSHEPE
x=eval(input("Enter a year:\n"))

if(x%3==0):
    print(x,"is not a leap year.")
elif(x%4==0):
    print(x,"is a leap year.")
else:
    print(x,"is not a leap year.")