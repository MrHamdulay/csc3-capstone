print("Welcome to the 30 Second Rule Expert\n------------------------------------\nAnswer the following questions by selecting from among the options.")

x=input("Did anyone see you? (yes/no)")
if(x=="yes"):
    r=input("\nWas it a boss/lover/parent? (yes/no)")
    if(r=="no"):
        print("\nDecision: Eat it.")
    if(r=="yes"):
        R=input("\nWas it expensive? (yes/no)")
        if(R=="yes"):
            d=input("\nCan you cut off the part that touched the floor? (yes/no) ")
            if(d=="yes"):
                print("\nDecision: Eat it.")
            if(d=="no"):
                print("\nDecision: Your call.")
        if(R=="no"):
            s=input("\nIs it chocolate? (yes/no)")
            if(s=="yes"):
                print("\nDecision: Eat it.")
            if(s=="no"):
                print("\nDecision: Don't eat it.")

if(x=="no"):
    tr=input("\nWas it sticky? (yes/no)")
    if(tr=="yes"):
        xo=input("\nIs it a raw steak? (yes/no)")
        if(xo=="yes"):
            jk=input("\nAre you a puma? (yes/no)")
            if(jk=="yes"):
                print("\nDecision: Eat it.")
            if(jk=="no"):
                print("\nDecision: Don't eat it.")
        if(xo=="no"):
            
          tri=input("\nDid the cat lick it? (yes/no)")  
          if(tri=="no"):
            print("\nDecision: Eat it.")
          if(tri=="yes"):
           s=input("\nIs your cat healthy? (yes/no)")
           
           if(s=="no"):
               print("\nDecision: Your call.")
           if(s=="yes"):
               print("\nDecision: Eat it.")
    if(tr=="no"):
        w=input("\nIs it an Emausaurus? (yes/no)")
        if(w=="yes"):
            es=input("\nAre you a Megalosaurus? (yes/no)")
            if(es=="yes"):
                print("\nDecision: Eat it.")
            if(es=="no"):
                print("\nDecision: Don't eat it.")
        if(w=="no"):
            trick=input("\nDid the cat lick it? (yes/no)")  
            if(trick=="no"):
             print("\nDecision: Eat it.")
            if(trick=="yes"):
             su=input("\nIs your cat healthy? (yes/no)")                  
             if(su=="no"):
              print("\nDecision: Your call.")
             if(su=="yes"):
              print("\nDecision: Eat it.")            
            
            
               
               
              
           
    

            
         
            
            
            
    
    