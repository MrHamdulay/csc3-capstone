import math

def main ():
    
    print ("Approximation of pi: 3.142")
    rad = eval(input("Enter the radius:\n"))
    
    pi = 3.141592654
    
    print ("Area:", round((pi*rad*rad),3))
    
    
main()