#Program tha calculates the value of PI, then computes and displays the area of a circle.
#Tsanwani Vhonani
#09 March 2014


import math

def PI():
        x=print("Approximation of pi:",(round(math.pi,3)))
        r=eval(input("Enter the radius:\n"))
        print("Area:",(round(3.1416*r**2,3)))
        
PI()


        
        



    
