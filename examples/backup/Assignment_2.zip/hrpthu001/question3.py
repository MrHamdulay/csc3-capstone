import math
x= math.pi
print("Approximation of pi:" ,round(x,3))
rad= eval(input("Enter the radius:\n"))
print("Area:" ,round(x*rad**2,3))