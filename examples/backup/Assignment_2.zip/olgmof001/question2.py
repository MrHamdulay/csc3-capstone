# a program called Welcome to the 30 Second Rule Expert
# Tofunmi Olagoke
# 13 March 2014
# OLGMOF001

print("Welcome to the 30 Second Rule Expert")
print("------------------------------------")
print("Answer the following questions by selecting from among the options.")

see=input("Did anyone see you? (yes/no)\n")
if see=="yes":
    lover=input("Was it a boss/lover/parent? (yes/no)\n")
    if lover=="no":
        print("Decision: Eat it.")
    else:
        expensive=input("Was it expensive? (yes/no)\n")
        if expensive=="no":
            chocolate=input("Is it chocolate? (yes/no)\n")
            if chocolate=="yes":
                print("Decision: Eat it.")
            else:
                print("Decision: Don't eat it.") 
        else:
            touch=input("Can you cut off the part that touched the floor? (yes/no)\n")
            if touch=="yes":
                print("Decision: Eat it.")
            else:
                print("Decision: Your call.")            

else:
    sticky=input("Was it sticky? (yes/no)\n")
    if sticky=="no":
        ema=input("Is it an Emausaurus? (yes/no)\n")
        if ema=="no":
            lick=input("Did the cat lick it? (yes/no)\n")
            if lick=="no":
                print("Decision: Eat it.")
            else:
                healthy=input("Is your cat healthy? (yes/no)\n")
                if healthy=="yes":
                    print("Decision: Eat it.")
                else:
                    print("Decision: Your call.") 
        else:
            mega=input("Are you a Megalosaurus? (yes/no)\n")
            if mega=="yes":
                print("Decision: Eat it.")
            else:
                print("Decision: Don't eat it.")              
    else:
        steak=input("Is it a raw steak? (yes/no)\n")
        if steak=="no":
            lick=input("Did the cat lick it? (yes/no)\n")
            if lick=="no":
                print("Decision: Eat it.")
            else:
                healthy=input("Is your cat healthy? (yes/no)\n")
                if healthy=="yes":
                    print("Decision: Eat it.")
                else:
                    print("Decision: Your call.")             
        else:
            puma=input("Are you a puma? (yes/no)\n")
            if puma=="yes":
                print("Decision: Eat it.")
            else:
                print("Decision: Don't eat it.")             
             
    
                 