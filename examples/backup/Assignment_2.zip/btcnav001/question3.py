def circle():
    x=3.14159
    print("Approximation of pi: 3.142")
    y=eval(input("Enter the radius:\n"))
    z=x*y*y
    a=round(z,3)
    print("Area:",a)
circle()

    
    