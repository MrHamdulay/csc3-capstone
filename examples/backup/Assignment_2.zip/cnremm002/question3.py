pi = 3.142
print ("Approximation of pi: 3.142") 
n = input("Enter the radius:\n")
n= int(n)
area = ( n ** 2 ) * pi
print ("Area:", area)