from math import pi
print("Approximation of pi: %.3f" % round(pi, 3))
print("Area: %.3f" % round(float(input("Enter the radius:\n"))**2*pi, 3))
