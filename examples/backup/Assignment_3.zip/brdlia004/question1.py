height = eval(input("Enter the height of the rectangle:\n"))

width = eval(input("Enter the width of the rectangle:\n"))
             
#height = height + 3

for i in range(height):
    print((width*"*"))