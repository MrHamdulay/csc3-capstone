
k=eval(input("Enter the height of the triangle:\n"))
for i in range(k+1):
    if(i!=0):
        print(" "*(k-i), end="")
        print("*"*((i*2)-1))    

    
    
    

