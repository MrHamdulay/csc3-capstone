def sq():
    a = input("Enter the height of the rectangle: \n")
    b = input("Enter the width of the rectangle:\n")
    x = eval(a)
    y = eval(b)
    for i in range(x):
        print("*"*y)
sq()       
