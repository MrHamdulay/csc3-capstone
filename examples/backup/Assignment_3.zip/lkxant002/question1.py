height=eval(input("Enter the height of the rectangle:\n"))
wid=eval(input("Enter the width of the rectangle:\n"))

for i in range(height):
    print(wid * "*")