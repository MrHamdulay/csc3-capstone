h = eval(input("Enter the height of the rectangle:\n"))
w = eval(input("Enter the width of the rectangle:\n"))
print(("*"*w+"\n")*h, end="")
