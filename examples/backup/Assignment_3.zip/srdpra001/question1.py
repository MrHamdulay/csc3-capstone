'''
Prashanth Sridharan
SRDPRA001
Assignment 3
Question 01
'''

ht = eval(input("Enter the height of the rectangle:\n"))
wh = eval(input("Enter the width of the rectangle:\n"))

p=0

while(p<ht):
    print("*"*wh)
    p=p+1