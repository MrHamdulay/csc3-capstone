# Author: Raees Eland
# Question 1: printing the height and width of a rectangle, given inputs.
# 25 March 2014

x=eval(input('Enter the height of the rectangle:\n'))
y=eval(input('Enter the width of the rectangle:\n'))
for i in range(x):
    print('*'*y)
    



