#Grant Meeser
#MSRGRA002
#25/03/2014

y=eval(input('Enter the height of the rectangle:\n'))
x=eval(input('Enter the width of the rectangle:\n'))

s='*'*x
s=(s+'\n')*y
print(s)
	
