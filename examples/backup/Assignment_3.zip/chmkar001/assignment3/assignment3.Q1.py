#karabo choma
#assignment 3


b=eval(input("Enter height:"))
c=eval(input("Enter width:"))
a=b+c
for i in range(b):
    print(c*"*")