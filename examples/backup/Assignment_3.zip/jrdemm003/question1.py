def main():
    height= eval(input("Enter the height of the rectangle:\n"))
    width= eval(input("Enter the width of the rectangle:\n"))
    
    x=0
    
    while x< height:
        
        print('*'*width)
        x=x+1
        
main()