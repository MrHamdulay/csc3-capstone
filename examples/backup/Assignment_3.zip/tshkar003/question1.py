#Assigment 3
#Program for printing rectangles
# by Karidas Tshintsholo

ubude = eval(input("Enter the height of the rectangle:\n"))
ubududla = eval(input("Enter the width of the rectangle:\n"))

for i in range(ubude):
        yes = "*"*ubududla
        print(yes)