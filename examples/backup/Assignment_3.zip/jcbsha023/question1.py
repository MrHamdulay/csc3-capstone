#program to draw a triangle
#Anthony Jacob
#21-March2014

def main():
    Height=eval(input("Enter the height of the rectangle:\n"))
    Width=eval(input("Enter the width of the rectangle:\n"))

    for i in range(Height):
        print('*'*Width)
main()           