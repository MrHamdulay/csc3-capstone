x= eval(input("Enter the height of the triangle:\n"))
for f in range(x): print((x-f-1)*' ', (2*(f)+1)*'*', sep='')
