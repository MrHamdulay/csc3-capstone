# Student Number: PRTNIC017
# Date: 3/16/14

height = eval(input('Enter the height of the rectangle:\n'))
width = eval(input('Enter the width of the rectangle:\n'))
for h in range(height):
    print('*' * width)