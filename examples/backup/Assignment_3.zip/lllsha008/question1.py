
h = eval(input('Enter the height of the rectangle:\n'))
print(('*' * eval(input('Enter the width of the rectangle:\n')) + '\n') * h, end = '')
