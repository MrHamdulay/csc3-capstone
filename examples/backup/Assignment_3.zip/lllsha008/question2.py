
x = eval(input('Enter the height of the triangle:\n'))
for i in range(x): print(' ' * (x - i - 1) + '*' * (2 * i + 1))
