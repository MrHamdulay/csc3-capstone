#Assignment 3
#Printing Rectangles
#RNikhil Jiten Naik
#25 March 2014

z = eval(input("Enter the height of the rectangle: \n"))
a = eval(input("Enter the width of the rectangle: \n"))

for i in range(z):
    print(a*"*")