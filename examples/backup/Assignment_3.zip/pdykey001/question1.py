height = eval(input("Enter the height of the rectangle:\n"))
width = eval(input("Enter the width of the rectangle:\n"))
i = 0
while i!=height:
    print("*"*width)
    i+=1