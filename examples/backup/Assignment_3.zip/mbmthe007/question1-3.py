height=eval(input("Enter the height of the rectangle:\n"))
width=eval(input("Enter the width of the rectangle:\n"))
def sq (width,height):
    for i in range (height):
        print('*'*width)
sq(width,height)
