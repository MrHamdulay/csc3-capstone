#Aiden Walton
#WLTAID001
#Program to draw a triangle

def rect():
    for i in range(1,x+1):
            print('*'*y)    
    
if __name__=="__main__":
    x=eval(input("Enter the height of the rectangle:\n"))
    y=eval(input("Enter the width of the rectangle:\n"))    
    rect()