H=eval(input("Enter the height of the rectangle:\n"))
W=eval(input("Enter the width of the rectangle:\n"))

for i in range(H):
    print('*'*W)

    
    

    