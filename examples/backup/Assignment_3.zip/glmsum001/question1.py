def rec():
    
    h=int(input("Enter the height of the rectangle: \n"))

    w=int(input("Enter the width of the rectangle: \n"))

    for i in range(0,h):
    
        print('*'*w)
        
rec()