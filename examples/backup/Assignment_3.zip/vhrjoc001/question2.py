

x=eval(input("Enter the height of the triangle:\n"))
b=(x-1)
for i in range(0,2*x,2):
    print(" "*(b),"*"*(i+1), sep ="")
    b=(b-1)
    
    
     
