ht = eval(input("Enter the height of the rectangle:\n"))
wt = eval(input("Enter the width of the rectangle:\n"))
sum = 0
for i in range(ht):
    
    print("*"*wt)
    
    