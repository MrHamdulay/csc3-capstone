height= eval(input("Enter the height of the triangle: \n"))
           
for j in range(1,height*2,2):
           height=height-1
           print(" "*(height)+j*'*')
           
         
           

 
   
    

    

