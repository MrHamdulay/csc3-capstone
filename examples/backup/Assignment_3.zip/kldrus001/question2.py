
b = eval(input('Enter the height of the triangle:\n'))
for i in range(b): print(' ' * (b - i - 1) + '*' * (2 * i + 1))
