#difference between using range and actual variable

x=eval(input("Enter the height of the rectangle: \n"))

q=eval(input("Enter the width of the rectangle: \n"))

for i in range(x):
    print('*'*q)

