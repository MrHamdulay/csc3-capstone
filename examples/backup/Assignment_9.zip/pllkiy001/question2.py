#program to reformat a text file
#kiyarah pillay
#16 may 2014

f_name=input("Enter the input filename:\n")
