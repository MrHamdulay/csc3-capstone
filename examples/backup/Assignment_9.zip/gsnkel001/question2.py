in=input("Enter the input filename")
out=input("Enter the output filename")
line_width=input("Enter the line width")
