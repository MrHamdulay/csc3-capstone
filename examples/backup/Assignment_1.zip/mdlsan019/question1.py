#Name:Sanele Mdlalose
#Student Number:MDLSAN019
#Date:05 March 2014
#Assignment 1,Question 1

print("  ____ ____ ___ ____  _____ _   _ _   _ _ ")
print(" / ___/ ___|_ _/ ___||  ___| | | | \ | | |")
print("| |   \___ \| |\___ \| |_  | | | |  \| | |")
print("| |___ ___) | | ___) |  _| | |_| | |\  |_|")
print(" \____|____/___|____/|_|    \___/|_| \_(_)")
