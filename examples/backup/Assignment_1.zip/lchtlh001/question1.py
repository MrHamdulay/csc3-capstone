# Tlholo Lichaba
# Program to create fancy effects
# 04 March 2014

print("_"*4, sep" ")