# Assignment 1: Question 1
# Produce ASCII Art Using Only Print()
# Author: Barnett Msiska(MSSBAR002)
# Date: 25/02/2014

def main():
    print("  ____ ____ ___ ____  _____ _   _ _   _ _ ", end="\n")
    print(" / ___/ ___|_ _/ ___||  ___| | | | \ | | |", end="\n")
    print("| |   \\___ \\| |\\___ \\| |_  | | | |  \\| | |", end="\n")
    print("| |___ ___) | | ___) |  _| | |_| | |\\  |_|", end="\n")
    print(" \\____|____/___|____/|_|    \\___/|_| \_(_)")

    
main()