space = " "
underscore = "_"
fwdslash = "/"
backslash = "\\"
line = "|"
oBracket = "("
cBracket = ")"
print(space*2,underscore*4,space,underscore*4,space,underscore*3,space,underscore*4,space*2,underscore*5,space,underscore,space*3,underscore,space,underscore,space*3,underscore,space,underscore,"\n",space,fwdslash,space,underscore*3,fwdslash,space,underscore*3,line,underscore,space,underscore,fwdslash,space,underscore*3,line*2,space*2,underscore*3,line,space,line,space,line,space,line,space,backslash,space,line,space,line,space,line,"\n",line,space,line,space*3,backslash,underscore*3,space,backslash,line,space,line,backslash,underscore*3,space,backslash,line,space,line,underscore,space*2,line,space,line,space,line,space,line,space*2,backslash,line,space,line,space,line,"\n",line,space,line,underscore*3,space,underscore*3,cBracket,space,line,space,line,space,underscore*3,cBracket,space,line,space*2,underscore,line,space,line,space,line,underscore,line,space,line,space,line,backslash,space*2,line,underscore,line,"\n",space,backslash,underscore*4,line,underscore*4,fwdslash,underscore*3,line,underscore*4,fwdslash,line,underscore,line,space*4,backslash,underscore*3,fwdslash,line,underscore,line,space,backslash,underscore,oBracket,underscore,cBracket,sep="")
