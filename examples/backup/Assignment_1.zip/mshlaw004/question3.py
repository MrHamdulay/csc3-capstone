FirstName=input("Enter first name:\n")
LastName=input("Enter last name:\n")
MoneyUSD=eval(input("Enter sum of money in USD:\n"))
Country=input("Enter country name:\n")
percentage=MoneyUSD*30//100
print("")
print("Dearest",FirstName)
print("It is with a heavy heart that I inform you of the death of my father,")
print("General Fayk",str(LastName)+",","your long lost relative from Mapsfostol.")
print("My father left the sum of",str(MoneyUSD)+"USD","for us, your distant cousins.")
print("Unfortunately, we cannot access the money as it is in a bank in",str(Country)+".")
print("I desperately need your assistance to access this money.")
print("I will even pay you generously, 30% of the amount -",str(percentage)+".0USD,")
print("for your help.  Please get in touch with me at this email address asap.")
print("Yours sincerely")
print("Frank",LastName)
    
    
    
    
    