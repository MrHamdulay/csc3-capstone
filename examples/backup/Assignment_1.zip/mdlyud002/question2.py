hours = input("Enter the hours:"+"\n")
minutes = input("Enter the minutes:"+"\n")
seconds = input("Enter the seconds:"+"\n")

if eval(hours)>=24 or eval(minutes)>=60 or eval(seconds)>=60:
    print("Your time is invalid.")
else:
    print("Your time is valid.")





    

