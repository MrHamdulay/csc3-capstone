a = input("Enter first name:\n")
b = input("Enter last name:\n")
c = eval(input("Enter sum of money in USD:\n"))
d = input("Enter country name:\n")
USD = "USD"
e = c*0.3
c = str(c) + USD
e = str(e) + USD
f = "30%"
print(" ")
print("Dearest",a)
print("It is with a heavy heart that I inform you of the death of my father,")
print("General Fayk",b,end=","" your long lost relative from Mapsfostol.\n")
print("My father left the sum of",c,"for us, your distant cousins.")
print("Unfortunately, we cannot access the money as it is in a bank in",d,end=".\n")
print("I desperately need your assistance to access this money.")
print("I will even pay you generously,",f,"of the amount -",e,end=",\n")
print("for your help.  Please get in touch with me at this email address asap.")
print("Yours sincerely")
print( "Frank", b )