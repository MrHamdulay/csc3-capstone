# Assignment 1 question 3
#By Nic Findlay 
#FNDNIC001

firstname= input("Enter first name:\n")
lastname= input("Enter last name:\n")
money= eval(input("Enter sum of money in USD:\n"))
country= input('Enter country name:\n')


print("\nDearest ", firstname, "\nIt is with a heavy heart that I inform you of the death of my father,", "\nGeneral Fayk ",lastname,", your long lost relative from Mapsfostol.", "\nMy father left the sum of ", money, "USD for us, your distant cousins.", "\nUnfortunately, we cannot access the money as it is in a bank in ", country,".\nI desperately need your assistance to access this money.", "\nI will even pay you generously, 30% of the amount - ", money*30/100, "USD,\nfor your help.  Please get in touch with me at this email address asap.", "\nYours sincerely", "\nFrank ", lastname,sep='')
