# This program prints ACSII art "CSISFUN!"

# Student Name: Simeon Nandjembo

# Student Number: NNDSIM001

# 06 March 2014

CSISFUN = """\
  ____ ____ ___ ____  _____ _   _ _   _ _ 
 / ___/ ___|_ _/ ___||  ___| | | | \\ | | |
| |   \\___ \\| |\\___ \\| |_  | | | |  \\| | |
| |___ ___) | | ___) |  _| | |_| | |\\  |_|
 \\____|____/___|____/|_|    \\___/|_| \\_(_)"""

print(CSISFUN,sep='')