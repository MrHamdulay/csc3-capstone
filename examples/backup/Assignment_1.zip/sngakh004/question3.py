# Question3.py
#Author: Akhil Singh
# 28 February 2014

x= input("Enter first name:\n")
y= input("Enter last name:\n")
z=eval(input("Enter sum of money in USD:\n"))
a=input("Enter country name:\n") 

print("\nDearest " , x,"\nIt is with a heavy heart that I inform you of the death of my father,\nGeneral Fayk ", y,", your long lost relative from Mapsfostol.\nMy father left the sum of ",z,"USD for us, your distant cousins.\nUnfortunately, we cannot access the money as it is in a bank in ", a,".\nI desperately need your assistance to access this money.\nI will even pay you generously, 30% of the amount - ",z*30/100,"USD,\nfor your help.  Please get in touch with me at this email address asap.\nYours sincerely\nFrank " ,y,sep=("")) 
