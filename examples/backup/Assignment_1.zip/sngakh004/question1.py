# Question 1.py
# using print statements for simple text
# author: Akhil SIngh
# 28 February 2014

print("  ____ ____ ___ ____  _____ _   _ _   _ _")
print(" / ___/ ___|_ _/ ___||  ___| | | | \ | | |")
print("| |   \___ \| |\___ \| |_  | | | |  \| | |")
print("| |___ ___) | | ___) |  _| | |_| | |\  |_|")
print(" \____|____/___|____/|_|    \___/|_| \_(_)")