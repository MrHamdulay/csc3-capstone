#question 3
#Program to generate a personalised spam message
#Michell Ndlozi
#NDLMIC004
first_name=input("Enter first name:\n")
last_name=input("Enter last name:\n")
z=eval(input("Enter sum of money in USD:\n"))
w=input("Enter country name:\n")
x= 0.3*z
print()
print("Dearest",first_name)
print("It is with a heavy heart that I inform you of the death of my father,")
print("General Fayk",last_name, end='')
print(", your long lost relative from Mapsfostol.")
print("My father left the sum of",z, end='')
print("USD for us, your distant cousins.")
print("Unfortunately, we cannot access the money as it is in a bank in",w, end='')
print(".")
print("I desperately need your assistance to access this money.")
print("I will even pay you generously, 30% of the amount -",x, end='')
print("USD,")
print("for your help.  Please get in touch with me at this email address asap.")
print("Yours sincerely")
print("Frank",last_name)
