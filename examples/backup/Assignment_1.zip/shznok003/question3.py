first_name = " "
print ("Enter first name:")
first_name = (input(""))
last_name= " "
print("Enter last name:")
last_name = (input(""))
money = 0
print ("Enter sum of money in USD:")
money = eval(input())
country= " "
print ("Enter country name:")
country = (input(""))
money30=0
money30 = money*0.3


print (" ")
print ("Dearest",first_name)
print ("It is with a heavy heart that I inform you of the death of my father,")
print ("General Fayk", last_name, end="," " your long lost relative from Mapsfostol. \n")
print ("My father left the sum of",money,end="USD for us, your distant cousins. \n")
print ("Unfortunately, we cannot access the money as it is in a bank in", country,end=". \n")
print ("I desperately need your assistance to access this money.")
print ("I will even pay you generously, 30% of the amount -",money30,end="USD, \n")
print ("for your help.  Please get in touch with me at this email address asap.")
print ("Yours sincerely")
print ("Frank", last_name)


