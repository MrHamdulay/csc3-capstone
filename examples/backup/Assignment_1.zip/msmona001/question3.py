#Question 3
#Assignment 1
#Onalerona Mosimege

FirstName = input("Enter first name:\n")
LastName = input("Enter last name:\n")
Money = input("Enter sum of money in USD:\n")
Country = input("Enter country name:\n")
Percentage = (eval(Money))*0.3

print(" ")
print("Dearest", FirstName,"\nIt is with a heavy heart that I inform you of the death of my father,\nGeneral Fayk", LastName + ", your long lost relative from Mapsfostol.\nMy father left the sum of", Money + "USD for us, your distant cousins.\nUnfortunately, we cannot access the money as it is in a bank in", Country + ".\nI desperately need your assistance to access this money.\nI will even pay you generously, 30% of the amount -", str(Percentage) + "USD,\nfor your help.  Please get in touch with me at this email address asap.", "\nYours sincerely", "\nFrank", LastName)