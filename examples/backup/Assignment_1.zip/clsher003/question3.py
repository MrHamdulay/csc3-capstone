# Spam message
# 3 March 2014

n=input("Enter first name:\n")
s=input("Enter last name:\n")
x=input("Enter sum of money in USD:\n")
c=input("Enter country name:\n")



print("\nDearest",n)
print("It is with a heavy heart that I inform you of the death of my father,")
print("General Fayk",s+", your long lost relative from Mapsfostol.")
print("My father left the sum of",x+"USD for us, your distant cousins.")
print("Unfortunately, we cannot access the money as it is in a bank in",c+".")
print("I desperately need your assistance to access this money.")

x=eval(x)
y=(30/100*x)
y=str(y)

print("I will even pay you generously, 30% of the amount -",y+"USD,")
print("for your help.  Please get in touch with me at this email address asap.")
print("Yours sincerely")
print("Frank",s)

