#Question 2 - Assignment 1
# Program to display ASCII art
#Nikhil Jiten Naik (NKXNIK003)
#3rd of March 2014

print ("  ____ ____ ___ ____  _____ _   _ _   _ _ ")
print (" / ___/ ___|_ _/ ___||  ___| | | | \\ | | |")
print ("| |   \\___ \\| |\\___ \\| |_  | | | |  \\| | |")
print ("| |___ ___) | | ___) |  _| | |_| | |\\  |_|")
print (" \\____|____/___|____/|_|    \\___/|_| \\_(_)")