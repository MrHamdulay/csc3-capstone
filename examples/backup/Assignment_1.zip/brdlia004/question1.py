#ASCII Art (Question 1)
#Name: Liam Brodie
#Student Number: BRDLIA004
#Date: 26 February 2014

print("  ____ ____ ___ ____  _____ _   _ _   _ _")
print(" / ___/ ___|_ _/ ___||  ___| | | | \ | | |")
print("| |   \___ \| |\___ \| |_  | | | |  \| | | ")
print("| |___ ___) | | ___) |  _| | |_| | |\  |_|")
print(" \____|____/___|____/|_|    \___/|_| \_(_)")