# question1.py
# A program which displays "CSISFUN" on screen, in block letters
# Name: Martin Batek
# Student Number: BTKMAR001
# Date: 25 February 2014

print("  ____ ____ ___ ____  _____ _   _ _   _ _ ")
print(" / ___/ ___|_ _/ ___||  ___| | | | \ | | |")
print("| |   \___ \| |\___ \| |_  | | | |  \| | |")
print("| |___ ___) | | ___) |  _| | |_| | |\  |_|")
print(" \____|____/___|____/|_|    \___/|_| \_(_)")