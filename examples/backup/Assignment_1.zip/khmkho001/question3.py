def main():
    f=input("Enter first name:\n")
    l=input("Enter last name:\n")
    m=eval(input("Enter sum of money in USD:\n"))
    c=input("Enter country name:\n")
    p=m*(3/10)
    print ("\nDearest",f,)
    print("It is with a heavy heart that I inform you of the death of my father,")
    print("General Fayk",l,end=", your long lost relative from Mapsfostol.\n")
    print("My father left the sum of",m,end="USD for us, your distant cousins.\n")
    print("Unfortunately, we cannot access the money as it is in a bank in",c,end=".\n")
    print("I desperately need your assistance to access this money.")
    print("I will even pay you generously, 30% of the amount -",p,end="USD,\n")
    print("for your help.  Please get in touch with me at this email address asap.")
    print("Yours sincerely")
    print("Frank",l,)


   
    
main()