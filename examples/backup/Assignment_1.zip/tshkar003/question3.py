# name: karidas tshintsholo
# assignment 1 : question 3

x=input("Enter first name:\n")
l=input("Enter last name:\n")
z=eval(input("Enter sum of money in USD:\n"))
y=input("Enter country name:\n")

print()
print("Dearest", x)
print("It is with a heavy heart that I inform you of the death of my father,")
print("General Fayk ", l,", your long lost relative from Mapsfostol.", sep="")
print("My father left the sum of ",z, "USD for us, your distant cousins.",sep="")
print("Unfortunately, we cannot access the money as it is in a bank in ",y, ".",sep="")
print("I desperately need your assistance to access this money.")
print("I will even pay you generously, 30% of the amount - ", (30/100)*z,"USD,",sep="")
print("for your help.  Please get in touch with me at this email address asap.")
print("Yours sincerely")
print("Frank",l)
