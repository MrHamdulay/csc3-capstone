a=input('Enter first name:\n')
b=input('Enter last name:\n')
c=eval(input('Enter sum of money in USD:\n'))
d=input('Enter country name:\n')
f=b+','
e30=str(0.3*c)+'USD,'
c=str(c)+'USD'
print()
print("Dearest",a)
print("It is with a heavy heart that I inform you of the death of my father,\nGeneral Fayk",f,"your long lost relative from Mapsfostol.") 
print("My father left the sum of",c,"for us, your distant cousins.")
print("Unfortunately, we cannot access the money as it is in a bank in",d,end='.')
print()
print("I desperately need your assistance to access this money.")
print("I will even pay you generously, 30% of the amount -",e30)
print('for your help.  Please get in touch with me at this email address asap.')
print('Yours sincerely')
print('Frank',b)
