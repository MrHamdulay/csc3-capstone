n = eval(input('Enter the hours:\n'))
a = eval(input('Enter the minutes:\n'))
o = eval(input('Enter the seconds:\n'))
if 0<=n<=23 and 0<=a<=59 and 0<=o<=59:
   print('Your time is valid.')
else:
   print('Your time is invalid.')

    
