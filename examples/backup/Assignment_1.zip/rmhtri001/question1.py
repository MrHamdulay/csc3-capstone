# Assignment1 : question1
# Name: Tristyn Ramiah
# Student Number: RMHTRI001
# Date: 07 March 2014

print("  ____ ____ ___ ____  _____ _   _ _   _ _ ")
print(" / ___/ ___|_ _/ ___||  ___| | | | \ | | |")
print("| |   \___ \| |\___ \| |_  | | | |  \| | |")
print("| |___ ___) | | ___) |  _| | |_| | |\  |_|")
print(" \____|____/___|____/|_|    \___/|_| \_(_)")
