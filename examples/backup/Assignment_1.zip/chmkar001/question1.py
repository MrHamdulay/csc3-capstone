#Question 1 of Assignment 1
#Modi Pascaline Antoinette Komana
#KMNMOD001
#February 2014
print  ("  ____ ____ ___ ____  _____ _   _ _   _ _\n / ___/ ___|_ _/ ___||  ___| | | | \ | | |\n| |   \___ \| |\___ \| |_  | | | |  \| | |\n| |___ ___) | | ___) |  _| | |_| | |\  |_|\n \____|____/___|____/|_|    \___/|_| \_(_)")