# Assignment 1 - Question 3
# Student Number: PRTNIC017
# 25 - 2 - 2014

name = input("Enter first name:\n")
# Patrick
surname = input("Enter last name:\n")
# Star
money = eval(input("Enter sum of money in USD:\n"))
# 1234
country = input("Enter country name:\n")
# South Africa

print("\nDearest ", name, sep="")
print("It is with a heavy heart that I inform you of the death of my father,", sep="")
print("General Fayk ", surname, ", your long lost relative from Mapsfostol.", sep="")
print("My father left the sum of ", money, "USD for us, your distant cousins.", sep="")
print("Unfortunately, we cannot access the money as it is in a bank in ", country, ".", sep="")
print("I desperately need your assistance to access this money.", sep="")
print("I will even pay you generously, 30% of the amount - ", (0.3 * money), "USD,", sep="")
print("for your help.  Please get in touch with me at this email address asap.", sep="")
print("Yours sincerely", sep="")
print("Frank ", surname, sep="")