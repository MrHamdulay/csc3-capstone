def main():
    x=input("Enter first name: \n")
    y=input("Enter last name: \n")
    z=eval(input("Enter sum of money in USD: \n"))
    a=input("Enter country name: \n")
    print("\nDearest",x,)
    print("It is with a heavy heart that I inform you of the death of my father,")
    print("General Fayk ",y,", your long lost relative from Mapsfostol.",sep='')
    print("My father left the sum of ",z,"USD for us, your distant cousins.",sep='')
    print("Unfortunately, we cannot access the money as it is in a bank in ",a,'.',sep='')
    print("I desperately need your assistance to access this money.")
    print("I will even pay you generously, 30% of the amount - ",z*(0.3),'USD,',sep='')
    print("for your help.  Please get in touch with me at this email address asap.")
    print("Yours sincerely")
    print("Frank",y)
    
    
          
main()          