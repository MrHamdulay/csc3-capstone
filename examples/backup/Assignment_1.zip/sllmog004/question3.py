# SLLMOG004
# CSC1015F Assignment 1
# Question 3

first_name=input("Enter first name:\n")
last_name=input("Enter last name:\n")
money=eval(input("Enter sum of money in USD:\n"))
country=input("Enter country name:\n")
print()
print("Dearest",first_name, end='\n')
print("It is with a heavy heart that I inform you of the death of my father,", end='\n')
print("General Fayk ",  last_name,", your long lost relative from Mapsfostol.", sep = "", end='\n')
print("My father left the sum of ", money,"USD for us, your distant cousins.", sep="", end='\n')
print("Unfortunately, we cannot access the money as it is in a bank in ", country,".", sep="", end='\n')
print("I desperately need your assistance to access this money.", end='\n')
print("I will even pay you generously, 30% of the amount - ", money*0.3,"USD,", sep="", end='\n')
print("for your help.  Please get in touch with me at this email address asap.", end='\n')
print("Yours sincerely", end='\n')
print("Frank", last_name)

