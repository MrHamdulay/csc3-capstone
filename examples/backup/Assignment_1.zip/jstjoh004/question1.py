#Hendrik Joosten
#JSTJOH004
#
#

#declare variables
a="_"
b="|"
c="/"
d="\\"
e=" "
f=")"
g="("

#print line 0
print(e,(a*4),(a*4),(a*3),(a*4)+e,(a*5),a,e,a,a,e,a,a,sep=" ",end="\n")
#print line 1
print(e+c,(a*3)+c,(a*3)+b+a,a+c,(a*3)+(b*2),e+(a*3)+b,b,b,b,d,b,b,b,sep=" ",end="\n")
#print line 2
print(b,b+(e*2),d+(a*3),d+b,b+d+(a*3),d+b,b+a+e,b,b,b,b+e,d+b,b,b,sep=" ",end="\n")
#print line 3
print(b,b+(a*3),(a*3)+f,b,b,(a*3)+f,b+e,a+b,b,b+a+b,b,b+d+e,b+a+b,sep=" ",end="\n")
#print line 4
print(e+d+(a*4)+b+(a*4)+c+(a*3)+b+(a*4)+c+b+a+b+(e*3),d+(a*3)+c+b+a+b,d+a+g+a+f,sep=" ",end="\n")   