
name = input('Enter first name:\n')
sur = input('Enter last name:\n')
mon = eval(input('Enter sum of money in USD:\n'))
con = input('Enter country name:\n')
mon30 = mon *0.3

print('\nDearest ', name, '\nIt is with a heavy heart that I inform you of the death of my father, \nGeneral Fayk ', sur ,', your long lost relative from Mapsfostol. \nMy father left the sum of ', mon, 'USD for us, your distant cousins. \nUnfortunately, we cannot access the money as it is in a bank in ', con, '. \nI desperately need your assistance to access this money. \nI will even pay you generously, 30% of the amount - ', mon30,'USD, \nfor your help.  Please get in touch with me at this email address asap. \nYours sincerely \nFrank ',sur, sep="")